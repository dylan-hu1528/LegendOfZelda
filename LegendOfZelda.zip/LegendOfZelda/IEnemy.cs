using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace Sprint2
{
    //Create an interface for any and all items, IItem
    public interface IEnemy
    {
        //update and draw methods go here
        void Update(GameTime gameTime);
        void Draw(SpriteBatch spriteBatch);
    }
}
