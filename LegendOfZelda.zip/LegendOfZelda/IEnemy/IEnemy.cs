using Microsoft.Xna.Framework.Graphics;

namespace Game1
{
    //Create an interface for any and all items, IItem
    public interface IEnemy
    {
        //update and draw methods go here
        void Update();
        void Draw(SpriteBatch spriteBatch);
    }
}
