﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game1
{
    class SkeletonEnemy : IEnemy
    {
        public Texture2D Texture { get; set; }
        private int locationY;
        private int locationX;
        private int Rows;
        private int Columns;
        private int currentFrame = 0;
        private int totalFrames = 2;
        int delay = 0;
        int change = 0;
        public SkeletonEnemy(Texture2D texture, int rows, int columns, Vector2 location)
        {
            Texture = texture;
            Rows = rows;
            Columns = columns;
            locationY = (int)location.Y;
            locationX = (int)location.X;
        }

        public void Update()
        {
            if (delay % 10 == 0)
            {
                currentFrame++;
                if (currentFrame == totalFrames)
                    currentFrame = 0;
            }
            delay++;

            if (change == 0)
            {
                    locationX -= 4;
            }
            else if (change == 1)
            {
                    locationY += 4;
            }
            else if (change == 2)
            {
                    locationX += 4;
            }
            else if (change == 3)
            {
                    locationY -= 4;
            }

            if (delay % 169 == 0)
            {
                change++;
                if (change == 4)
                    change = 0;
            }

            if (locationY < -44)
            {
                locationY = 480;
            }
            if (locationY > 480)
            {
                locationY = -44;
            }
            if (locationX < -36)
            {
                locationX = 800;
            }
            if (locationX > 800)
            {
                locationX = -36;
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            int width = Texture.Width / Columns;
            int height = Texture.Height / Rows;

            Rectangle sourceRectangle = new Rectangle(currentFrame * width, 0, width, height);
            Rectangle destinationRectangle = new Rectangle(locationX, locationY, 2 * width, 2 * height);


            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }

    }

}