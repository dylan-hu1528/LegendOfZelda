﻿namespace Game1
{
    interface IController
    {
        void Update();
    }
}