﻿namespace Game1.GeneralCommands
{
    class QuitCommand : ICommand
    {
        Game1 Game { get; set; }
        public QuitCommand(Game1 game)
        {
            Game = game;
        }
        public void Execute()
        {
            Game.Exit();
        }
    }
}
