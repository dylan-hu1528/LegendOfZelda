﻿namespace Game1.GeneralCommands
{
    class ResetCommand : ICommand
    {
        Game1 Game { get; set; }
        public ResetCommand(Game1 game)
        {
            Game = game;
        }
        public void Execute()
        {
            Game.Reset();
        }
    }
}
