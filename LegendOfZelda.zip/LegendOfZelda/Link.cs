﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Game1
{
    public class Link : IPlayer
    {
        private LinkStateMachine LinkStateMachine { get; set; }
        private ISprite Sprite { get; set; }
        public Game1 Game { get; set; }

        public Vector2 Location { get; set; }

        public Link(Game1 game)
        {
            Game = game;
            Location = new Vector2(200, 200);
            Sprite = new LinkSprites.LinkIdleSprite(Game.TextureLoader.GetTexture("greenlinkrundown"));
            LinkStateMachine = new LinkStateMachine(Game, this);
        }

        public void SetDirection(string dir)
        {
            LinkStateMachine.SetDirection(dir);
        }

        public void SetHealth(int num)
        {
            LinkStateMachine.SetHealth(num);
        }

        public void SetWeapon(string weapon)
        {
            LinkStateMachine.SetWeapon(weapon);
        }

        public void SetSprite(ISprite sprite)
        {
            Sprite = sprite;
        }

        public void SetIsMoving(bool tf)
        {
            LinkStateMachine.SetIsMoving(tf);
        }

        public void SetIsAttacking()
        {
            LinkStateMachine.SetIsAttacking();
        }

        public LinkStateMachine GetStateMachine()
        {
            return LinkStateMachine;
        }

        public Vector2 GetLocation()
        {
            return Location;
        }

        public void Update()
        {
            if (LinkStateMachine.IsMoving())
            {
                switch (LinkStateMachine.Facing())
                {
                    case LinkStateMachine.Direction.Down: 
                        Location = new Vector2(Location.X, Location.Y + 3);
                        break;
                    case LinkStateMachine.Direction.Up:
                        Location = new Vector2(Location.X, Location.Y - 3);
                        break;
                    case LinkStateMachine.Direction.Left:
                        Location = new Vector2(Location.X - 3, Location.Y);
                        break;
                    case LinkStateMachine.Direction.Right:
                        Location = new Vector2(Location.X + 3, Location.Y);
                        break;
                }
            }

            if(LinkStateMachine.DamageCounter() > 0)
            {
                LinkStateMachine.DecDamageCounter();
                LinkStateMachine.SetIsHurt(true);
            }
            else
            {
                LinkStateMachine.SetIsHurt(false);
            }

            if(LinkStateMachine.AttackCounter() > 0)
            {
                LinkStateMachine.DecAttackCounter();
            }

            if(LinkStateMachine.ShootSwordCounter() > 0)
            {
                LinkStateMachine.DecShootSwordCounter();
            }

            Sprite.Update();
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            Sprite.Draw(spriteBatch, Location);
        }
    }
}
