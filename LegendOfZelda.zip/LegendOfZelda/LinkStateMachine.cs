﻿using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Game1
{
    public class LinkStateMachine : IStateMachine
    {
        public enum Direction
        {
            Up, Down, Left, Right
        }
        public enum SuitColor
        {
            Green, Blue, Red
        }
        public enum Weapon
        {
            NoWeapon, WoodenSword, WhiteSword, MagicalSword, MagicalRod
        }
        public enum Shield
        {
            WoodenShield, MagicalShield
        }
        private Direction facing;
        private SuitColor color;
        private Weapon weapon;
        private Shield shield;
        private int currenthealth, maxhealth;
        private int damagecounter, attackcounter, shootswordcounter;
        private bool isMoving, isAttacking, isHurt;

        private IPlayer Player { get; set; }
        private Game1 Game { get; set; }

        private Dictionary<string, ISprite> sprites;

        public LinkStateMachine(Game1 game, IPlayer player)
        {
            facing = Direction.Down;
            color = SuitColor.Green;
            weapon = Weapon.WoodenSword;
            shield = Shield.WoodenShield;
            maxhealth = 6;
            currenthealth = maxhealth;
            isMoving = false;
            isAttacking = false;
            isHurt = false;

            damagecounter = 0;
            attackcounter = 0;
            shootswordcounter = 0;

            Game = game;
            Player = player;

            sprites = new Dictionary<string, ISprite>();
            LoadSprites();
        }

        private void LoadSprites()
        {
            // Regular sprites
            sprites.Add("greenlinkrunup", new LinkSprites.LinkRunSprite(Game.TextureLoader.GetTexture("greenlinkrunup")));
            sprites.Add("greenlinkrundown", new LinkSprites.LinkRunSprite(Game.TextureLoader.GetTexture("greenlinkrundown")));
            sprites.Add("greenlinkrunleft", new LinkSprites.LinkRunSprite(Game.TextureLoader.GetTexture("greenlinkrunleft")));
            sprites.Add("greenlinkrunright", new LinkSprites.LinkRunSprite(Game.TextureLoader.GetTexture("greenlinkrunright")));
            sprites.Add("greenlinkrunupmagicshield", new LinkSprites.LinkRunSprite(Game.TextureLoader.GetTexture("greenlinkrunup")));
            sprites.Add("greenlinkrundownmagicshield", new LinkSprites.LinkRunSprite(Game.TextureLoader.GetTexture("greenlinkrundownmagicshield")));
            sprites.Add("greenlinkrunleftmagicshield", new LinkSprites.LinkRunSprite(Game.TextureLoader.GetTexture("greenlinkrunleftmagicshield")));
            sprites.Add("greenlinkrunrightmagicshield", new LinkSprites.LinkRunSprite(Game.TextureLoader.GetTexture("greenlinkrunrightmagicshield")));
            sprites.Add("greenlinkidleup", new LinkSprites.LinkIdleSprite(Game.TextureLoader.GetTexture("greenlinkrunup")));
            sprites.Add("greenlinkidledown", new LinkSprites.LinkIdleSprite(Game.TextureLoader.GetTexture("greenlinkrundown")));
            sprites.Add("greenlinkidleleft", new LinkSprites.LinkIdleSprite(Game.TextureLoader.GetTexture("greenlinkrunleft")));
            sprites.Add("greenlinkidleright", new LinkSprites.LinkIdleSprite(Game.TextureLoader.GetTexture("greenlinkrunright")));
            sprites.Add("greenlinkidleupmagicshield", new LinkSprites.LinkIdleSprite(Game.TextureLoader.GetTexture("greenlinkrunup")));
            sprites.Add("greenlinkidledownmagicshield", new LinkSprites.LinkIdleSprite(Game.TextureLoader.GetTexture("greenlinkrundownmagicshield")));
            sprites.Add("greenlinkidleleftmagicshield", new LinkSprites.LinkIdleSprite(Game.TextureLoader.GetTexture("greenlinkrunleftmagicshield")));
            sprites.Add("greenlinkidlerightmagicshield", new LinkSprites.LinkIdleSprite(Game.TextureLoader.GetTexture("greenlinkrunrightmagicshield")));
            sprites.Add("greenlinkwoodenswordattackdown", new LinkSprites.LinkAttackDownSprite(Game.TextureLoader.GetTexture("greenlinkwoodenswordattackdown")));
            sprites.Add("greenlinkwoodenswordattackup", new LinkSprites.LinkAttackUpSprite(Game.TextureLoader.GetTexture("greenlinkwoodenswordattackup")));
            sprites.Add("greenlinkwoodenswordattackleft", new LinkSprites.LinkAttackLeftSprite(Game.TextureLoader.GetTexture("greenlinkwoodenswordattackleft")));
            sprites.Add("greenlinkwoodenswordattackright", new LinkSprites.LinkAttackRightSprite(Game.TextureLoader.GetTexture("greenlinkwoodenswordattackright")));

            // Hurt sprites - flash colors
            sprites.Add("hurtgreenlinkrunup", new LinkSprites.HurtLinkRunSprite(Game.TextureLoader.GetTexture("greenlinkrunup")));
            sprites.Add("hurtgreenlinkrundown", new LinkSprites.HurtLinkRunSprite(Game.TextureLoader.GetTexture("greenlinkrundown")));
            sprites.Add("hurtgreenlinkrunleft", new LinkSprites.HurtLinkRunSprite(Game.TextureLoader.GetTexture("greenlinkrunleft")));
            sprites.Add("hurtgreenlinkrunright", new LinkSprites.HurtLinkRunSprite(Game.TextureLoader.GetTexture("greenlinkrunright")));
            sprites.Add("hurtgreenlinkrunupmagicshield", new LinkSprites.HurtLinkRunSprite(Game.TextureLoader.GetTexture("greenlinkrunup")));
            sprites.Add("hurtgreenlinkrundownmagicshield", new LinkSprites.HurtLinkRunSprite(Game.TextureLoader.GetTexture("greenlinkrundownmagicshield")));
            sprites.Add("hurtgreenlinkrunleftmagicshield", new LinkSprites.HurtLinkRunSprite(Game.TextureLoader.GetTexture("greenlinkrunleftmagicshield")));
            sprites.Add("hurtgreenlinkrunrightmagicshield", new LinkSprites.HurtLinkRunSprite(Game.TextureLoader.GetTexture("greenlinkrunrightmagicshield")));
            sprites.Add("hurtgreenlinkidleup", new LinkSprites.HurtLinkIdleSprite(Game.TextureLoader.GetTexture("greenlinkrunup")));
            sprites.Add("hurtgreenlinkidledown", new LinkSprites.HurtLinkIdleSprite(Game.TextureLoader.GetTexture("greenlinkrundown")));
            sprites.Add("hurtgreenlinkidleleft", new LinkSprites.HurtLinkIdleSprite(Game.TextureLoader.GetTexture("greenlinkrunleft")));
            sprites.Add("hurtgreenlinkidleright", new LinkSprites.HurtLinkIdleSprite(Game.TextureLoader.GetTexture("greenlinkrunright")));
            sprites.Add("hurtgreenlinkidleupmagicshield", new LinkSprites.HurtLinkIdleSprite(Game.TextureLoader.GetTexture("greenlinkrunup")));
            sprites.Add("hurtgreenlinkidledownmagicshield", new LinkSprites.HurtLinkIdleSprite(Game.TextureLoader.GetTexture("greenlinkrundownmagicshield")));
            sprites.Add("hurtgreenlinkidleleftmagicshield", new LinkSprites.HurtLinkIdleSprite(Game.TextureLoader.GetTexture("greenlinkrunleftmagicshield")));
            sprites.Add("hurtgreenlinkidlerightmagicshield", new LinkSprites.HurtLinkIdleSprite(Game.TextureLoader.GetTexture("greenlinkrunrightmagicshield")));
            sprites.Add("hurtgreenlinkwoodenswordattackdown", new LinkSprites.HurtLinkAttackDownSprite(Game.TextureLoader.GetTexture("greenlinkwoodenswordattackdown")));
            sprites.Add("hurtgreenlinkwoodenswordattackup", new LinkSprites.HurtLinkAttackUpSprite(Game.TextureLoader.GetTexture("greenlinkwoodenswordattackup")));
            sprites.Add("hurtgreenlinkwoodenswordattackleft", new LinkSprites.HurtLinkAttackLeftSprite(Game.TextureLoader.GetTexture("greenlinkwoodenswordattackleft")));
            sprites.Add("hurtgreenlinkwoodenswordattackright", new LinkSprites.HurtLinkAttackRightSprite(Game.TextureLoader.GetTexture("greenlinkwoodenswordattackright")));
        }

        public void SetDirection(string dir)
        {
            switch (dir)
            {
                case "up": facing = Direction.Up;
                    break;
                case "down": facing = Direction.Down;
                    break;
                case "left": facing = Direction.Left;
                    break;
                case "right": facing = Direction.Right;
                    break;
            }
        }

        public void SetColor(string col)
        {
            switch (col)
            {
                case "green": color = SuitColor.Green;
                    break;
                case "blue": color = SuitColor.Blue;
                    break;
                case "red": color = SuitColor.Red;
                    break;
            }
        }

        public void SetWeapon(string weap)
        {
            switch (weap)
            {
                case "noweapon": weapon = Weapon.NoWeapon;
                    break;
                case "woodensword": weapon = Weapon.WoodenSword;
                    break;
                case "whitesword": weapon = Weapon.WhiteSword;
                    break;
                case "magicsword": weapon = Weapon.MagicalSword;
                    break;
                case "magicrod": weapon = Weapon.MagicalRod;
                    break;
            }
        }

        public void SetShield(string shi)
        {
            switch (shi)
            {
                case "woodenshield": shield = Shield.WoodenShield;
                    break;
                case "magicshield": shield = Shield.MagicalShield;
                    break;
            }
        }

        public void SetHealth(int num)
        {
            if (damagecounter == 0 && num < 0 || damagecounter != 0 && num > 0)
            {
                currenthealth += num;
                if (currenthealth > maxhealth)
                    currenthealth = maxhealth;
            }
            if (num < 0)
                damagecounter = 120;
            if(currenthealth <= 0)
            {
                // Link dies
            }

        }

        public void DecDamageCounter()
        {
            damagecounter--;
        }

        public int DamageCounter()
        {
            return damagecounter;
        }

        public void SetIsMoving(bool tf)
        {
            isMoving = tf;
        }

        public void SetIsHurt(bool tf)
        {
            isHurt = tf;
        }

        public void SetIsAttacking()
        {
            if(attackcounter == 0)
                attackcounter = 21;
            if (currenthealth == maxhealth && shootswordcounter == 0)
                shootswordcounter = 60;
        }

        public void DecAttackCounter()
        {
            attackcounter--;
        }

        public int AttackCounter()
        {
            return attackcounter;
        }

        public void DecShootSwordCounter()
        {
            shootswordcounter--;
        }

        public int ShootSwordCounter()
        {
            return shootswordcounter;
        }

        // Sets the current sprite according to state values
        public void SetSprite()
        {
            isAttacking = attackcounter > 0;
            switch (isAttacking)
            {
                case true:
                    switch (isHurt)
                    {
                        case true:
                            switch (facing)
                            {
                                case Direction.Up:
                                    switch (weapon)
                                    {
                                        case Weapon.WoodenSword:
                                            Player.SetSprite(sprites["hurtgreenlinkwoodenswordattackup"]);
                                            if (shootswordcounter > 58)
                                            {
                                                Game.AddLinkProjectile(new IProjectiles.Sword(Game.TextureLoader.GetTexture("swordbeamup"), new Vector2(Player.GetLocation().X + 6, Player.GetLocation().Y), "up"));
                                            }
                                            break;
                                        case Weapon.WhiteSword:
                                            break;
                                        case Weapon.MagicalSword:
                                            break;
                                        case Weapon.MagicalRod:
                                            break;
                                    }
                                    break;
                                case Direction.Down:
                                    switch (weapon)
                                    {
                                        case Weapon.WoodenSword:
                                            Player.SetSprite(sprites["hurtgreenlinkwoodenswordattackdown"]);
                                            if (shootswordcounter > 58)
                                            {
                                                Game.AddLinkProjectile(new IProjectiles.Sword(Game.TextureLoader.GetTexture("swordbeamdown"), new Vector2(Player.GetLocation().X + 8, Player.GetLocation().Y + 11), "down"));
                                            }
                                            break;
                                        case Weapon.WhiteSword:
                                            break;
                                        case Weapon.MagicalSword:
                                            break;
                                        case Weapon.MagicalRod:
                                            break;
                                    }
                                    break;
                                case Direction.Left:
                                    switch (weapon)
                                    {
                                        case Weapon.WoodenSword:
                                            Player.SetSprite(sprites["hurtgreenlinkwoodenswordattackleft"]);
                                            if (shootswordcounter > 58)
                                            {
                                                Game.AddLinkProjectile(new IProjectiles.Sword(Game.TextureLoader.GetTexture("swordbeamkleft"), new Vector2(Player.GetLocation().X, Player.GetLocation().Y + 2), "left"));
                                            }
                                            break;
                                        case Weapon.WhiteSword:
                                            break;
                                        case Weapon.MagicalSword:
                                            break;
                                        case Weapon.MagicalRod:
                                            break;
                                    }
                                    break;
                                case Direction.Right:
                                    switch (weapon)
                                    {
                                        case Weapon.WoodenSword:
                                            Player.SetSprite(sprites["hurtgreenlinkwoodenswordattackright"]);
                                            if (shootswordcounter > 58)
                                            {
                                                Game.AddLinkProjectile(new IProjectiles.Sword(Game.TextureLoader.GetTexture("swordbeamright"), new Vector2(Player.GetLocation().X + 11, Player.GetLocation().Y + 2), "right"));
                                            }
                                            break;
                                        case Weapon.WhiteSword:
                                            break;
                                        case Weapon.MagicalSword:
                                            break;
                                        case Weapon.MagicalRod:
                                            break;
                                    }
                                    break;
                            }
                            break;
                        case false:
                            switch (facing)
                            {
                                case Direction.Up:
                                    switch (weapon)
                                    {
                                        case Weapon.WoodenSword:
                                            Player.SetSprite(sprites["greenlinkwoodenswordattackup"]);
                                            if (shootswordcounter > 58)
                                            {
                                                Game.AddLinkProjectile(new IProjectiles.Sword(Game.TextureLoader.GetTexture("swordbeamup"), new Vector2(Player.GetLocation().X + 6, Player.GetLocation().Y), "up"));
                                            }
                                            break;
                                        case Weapon.WhiteSword:
                                            break;
                                        case Weapon.MagicalSword:
                                            break;
                                        case Weapon.MagicalRod:
                                            break;
                                    }
                                    break;
                                case Direction.Down:
                                    switch (weapon)
                                    {
                                        case Weapon.WoodenSword:
                                            Player.SetSprite(sprites["greenlinkwoodenswordattackdown"]);
                                            if (shootswordcounter > 58)
                                            {
                                                Game.AddLinkProjectile(new IProjectiles.Sword(Game.TextureLoader.GetTexture("swordbeamdown"), new Vector2(Player.GetLocation().X + 8, Player.GetLocation().Y + 11), "down"));
                                            }
                                            break;
                                        case Weapon.WhiteSword:
                                            break;
                                        case Weapon.MagicalSword:
                                            break;
                                        case Weapon.MagicalRod:
                                            break;
                                    }
                                    break;
                                case Direction.Left:
                                    switch (weapon)
                                    {
                                        case Weapon.WoodenSword:
                                            Player.SetSprite(sprites["greenlinkwoodenswordattackleft"]);
                                            if (shootswordcounter > 58)
                                            {
                                                Game.AddLinkProjectile(new IProjectiles.Sword(Game.TextureLoader.GetTexture("swordbeamleft"), new Vector2(Player.GetLocation().X, Player.GetLocation().Y + 2), "left"));
                                            }
                                            break;
                                        case Weapon.WhiteSword:
                                            break;
                                        case Weapon.MagicalSword:
                                            break;
                                        case Weapon.MagicalRod:
                                            break;
                                    }
                                    break;
                                case Direction.Right:
                                    switch (weapon)
                                    {
                                        case Weapon.WoodenSword:
                                            Player.SetSprite(sprites["greenlinkwoodenswordattackright"]);
                                            if (shootswordcounter > 58)
                                            {
                                                Game.AddLinkProjectile(new IProjectiles.Sword(Game.TextureLoader.GetTexture("swordbeamright"), new Vector2(Player.GetLocation().X + 11, Player.GetLocation().Y + 2), "right"));
                                            }
                                            break;
                                        case Weapon.WhiteSword:
                                            break;
                                        case Weapon.MagicalSword:
                                            break;
                                        case Weapon.MagicalRod:
                                            break;
                                    }
                                    break;
                            }
                            break;
                    }
                    break;
                case false:
                    switch (isHurt)
                    {
                        case true:
                            switch (isMoving)
                            {
                                case true:
                                    switch (shield)
                                    {
                                        case Shield.WoodenShield:
                                            switch (color)
                                            {
                                                case SuitColor.Green:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            Player.SetSprite(sprites["hurtgreenlinkrunup"]);
                                                            break;
                                                        case Direction.Down:
                                                            Player.SetSprite(sprites["hurtgreenlinkrundown"]);
                                                            break;
                                                        case Direction.Left:
                                                            Player.SetSprite(sprites["hurtgreenlinkrunleft"]);
                                                            break;
                                                        case Direction.Right:
                                                            Player.SetSprite(sprites["hurtgreenlinkrunright"]);
                                                            break;
                                                    }
                                                    break;
                                                case SuitColor.Blue:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            break;
                                                        case Direction.Down:
                                                            break;
                                                        case Direction.Left:
                                                            break;
                                                        case Direction.Right:
                                                            break;
                                                    }
                                                    break;
                                                case SuitColor.Red:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            break;
                                                        case Direction.Down:
                                                            break;
                                                        case Direction.Left:
                                                            break;
                                                        case Direction.Right:
                                                            break;
                                                    }
                                                    break;
                                            }
                                            break;
                                        case Shield.MagicalShield:
                                            switch (color)
                                            {
                                                case SuitColor.Green:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            Player.SetSprite(sprites["hurtgreenlinkrunupmagicshield"]);
                                                            break;
                                                        case Direction.Down:
                                                            Player.SetSprite(sprites["hurtgreenlinkrundownmagicshield"]);
                                                            break;
                                                        case Direction.Left:
                                                            Player.SetSprite(sprites["hurtgreenlinkrunleftmagicshield"]);
                                                            break;
                                                        case Direction.Right:
                                                            Player.SetSprite(sprites["hurtgreenlinkrunrightmagicshield"]);
                                                            break;
                                                    }
                                                    break;
                                                case SuitColor.Blue:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            break;
                                                        case Direction.Down:
                                                            break;
                                                        case Direction.Left:
                                                            break;
                                                        case Direction.Right:
                                                            break;
                                                    }
                                                    break;
                                                case SuitColor.Red:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            break;
                                                        case Direction.Down:
                                                            break;
                                                        case Direction.Left:
                                                            break;
                                                        case Direction.Right:
                                                            break;
                                                    }
                                                    break;
                                            }
                                            break;
                                    }
                                    break;
                                case false:
                                    switch (shield)
                                    {
                                        case Shield.WoodenShield:
                                            switch (color)
                                            {
                                                case SuitColor.Green:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            Player.SetSprite(sprites["hurtgreenlinkidleup"]);
                                                            break;
                                                        case Direction.Down:
                                                            Player.SetSprite(sprites["hurtgreenlinkidledown"]);
                                                            break;
                                                        case Direction.Left:
                                                            Player.SetSprite(sprites["hurtgreenlinkidleleft"]);
                                                            break;
                                                        case Direction.Right:
                                                            Player.SetSprite(sprites["hurtgreenlinkidleright"]);
                                                            break;
                                                    }
                                                    break;
                                                case SuitColor.Blue:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            break;
                                                        case Direction.Down:
                                                            break;
                                                        case Direction.Left:
                                                            break;
                                                        case Direction.Right:
                                                            break;
                                                    }
                                                    break;
                                                case SuitColor.Red:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            break;
                                                        case Direction.Down:
                                                            break;
                                                        case Direction.Left:
                                                            break;
                                                        case Direction.Right:
                                                            break;
                                                    }
                                                    break;
                                            }
                                            break;
                                        case Shield.MagicalShield:
                                            switch (color)
                                            {
                                                case SuitColor.Green:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            Player.SetSprite(sprites["hurtgreenlinkidleupmagicshield"]);
                                                            break;
                                                        case Direction.Down:
                                                            Player.SetSprite(sprites["hurtgreenlinkidledownmagicshield"]);
                                                            break;
                                                        case Direction.Left:
                                                            Player.SetSprite(sprites["hurtgreenlinkidleleftmagicshield"]);
                                                            break;
                                                        case Direction.Right:
                                                            Player.SetSprite(sprites["hurtgreenlinkidlerightmagicshield"]);
                                                            break;
                                                    }
                                                    break;
                                                case SuitColor.Blue:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            break;
                                                        case Direction.Down:
                                                            break;
                                                        case Direction.Left:
                                                            break;
                                                        case Direction.Right:
                                                            break;
                                                    }
                                                    break;
                                                case SuitColor.Red:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            break;
                                                        case Direction.Down:
                                                            break;
                                                        case Direction.Left:
                                                            break;
                                                        case Direction.Right:
                                                            break;
                                                    }
                                                    break;
                                            }
                                            break;
                                    }
                                    break;
                            }
                            break;
                        case false:
                            switch (isMoving)
                            {
                                case true:
                                    switch (shield)
                                    {
                                        case Shield.WoodenShield:
                                            switch (color)
                                            {
                                                case SuitColor.Green:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            Player.SetSprite(sprites["greenlinkrunup"]);
                                                            break;
                                                        case Direction.Down:
                                                            Player.SetSprite(sprites["greenlinkrundown"]);
                                                            break;
                                                        case Direction.Left:
                                                            Player.SetSprite(sprites["greenlinkrunleft"]);
                                                            break;
                                                        case Direction.Right:
                                                            Player.SetSprite(sprites["greenlinkrunright"]);
                                                            break;
                                                    }
                                                    break;
                                                case SuitColor.Blue:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            break;
                                                        case Direction.Down:
                                                            break;
                                                        case Direction.Left:
                                                            break;
                                                        case Direction.Right:
                                                            break;
                                                    }
                                                    break;
                                                case SuitColor.Red:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            break;
                                                        case Direction.Down:
                                                            break;
                                                        case Direction.Left:
                                                            break;
                                                        case Direction.Right:
                                                            break;
                                                    }
                                                    break;
                                            }
                                            break;
                                        case Shield.MagicalShield:
                                            switch (color)
                                            {
                                                case SuitColor.Green:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            Player.SetSprite(sprites["greenlinkrunupmagicshield"]);
                                                            break;
                                                        case Direction.Down:
                                                            Player.SetSprite(sprites["greenlinkrundownmagicshield"]);
                                                            break;
                                                        case Direction.Left:
                                                            Player.SetSprite(sprites["greenlinkrunleftmagicshield"]);
                                                            break;
                                                        case Direction.Right:
                                                            Player.SetSprite(sprites["greenlinkrunrightmagicshield"]);
                                                            break;
                                                    }
                                                    break;
                                                case SuitColor.Blue:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            break;
                                                        case Direction.Down:
                                                            break;
                                                        case Direction.Left:
                                                            break;
                                                        case Direction.Right:
                                                            break;
                                                    }
                                                    break;
                                                case SuitColor.Red:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            break;
                                                        case Direction.Down:
                                                            break;
                                                        case Direction.Left:
                                                            break;
                                                        case Direction.Right:
                                                            break;
                                                    }
                                                    break;
                                            }
                                            break;
                                    }
                                    break;
                                case false:
                                    switch (shield)
                                    {
                                        case Shield.WoodenShield:
                                            switch (color)
                                            {
                                                case SuitColor.Green:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            Player.SetSprite(sprites["greenlinkidleup"]);
                                                            break;
                                                        case Direction.Down:
                                                            Player.SetSprite(sprites["greenlinkidledown"]);
                                                            break;
                                                        case Direction.Left:
                                                            Player.SetSprite(sprites["greenlinkidleleft"]);
                                                            break;
                                                        case Direction.Right:
                                                            Player.SetSprite(sprites["greenlinkidleright"]);
                                                            break;
                                                    }
                                                    break;
                                                case SuitColor.Blue:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            break;
                                                        case Direction.Down:
                                                            break;
                                                        case Direction.Left:
                                                            break;
                                                        case Direction.Right:
                                                            break;
                                                    }
                                                    break;
                                                case SuitColor.Red:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            break;
                                                        case Direction.Down:
                                                            break;
                                                        case Direction.Left:
                                                            break;
                                                        case Direction.Right:
                                                            break;
                                                    }
                                                    break;
                                            }
                                            break;
                                        case Shield.MagicalShield:
                                            switch (color)
                                            {
                                                case SuitColor.Green:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            Player.SetSprite(sprites["greenlinkidleupmagicshield"]);
                                                            break;
                                                        case Direction.Down:
                                                            Player.SetSprite(sprites["greenlinkidledownmagicshield"]);
                                                            break;
                                                        case Direction.Left:
                                                            Player.SetSprite(sprites["greenlinkidleleftmagicshield"]);
                                                            break;
                                                        case Direction.Right:
                                                            Player.SetSprite(sprites["greenlinkidlerightmagicshield"]);
                                                            break;
                                                    }
                                                    break;
                                                case SuitColor.Blue:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            break;
                                                        case Direction.Down:
                                                            break;
                                                        case Direction.Left:
                                                            break;
                                                        case Direction.Right:
                                                            break;
                                                    }
                                                    break;
                                                case SuitColor.Red:
                                                    switch (facing)
                                                    {
                                                        case Direction.Up:
                                                            break;
                                                        case Direction.Down:
                                                            break;
                                                        case Direction.Left:
                                                            break;
                                                        case Direction.Right:
                                                            break;
                                                    }
                                                    break;
                                            }
                                            break;
                                    }
                                    break;
                            }
                            break;
                    }
                    break;
            }
        }

        public Direction Facing()
        {
            return facing;
        }

        public SuitColor Color()
        {
            return color;
        }

        public Weapon EquippedWeapon()
        {
            return weapon;
        }

        public Shield EquippedShield()
        {
            return shield;
        }

        public int Health()
        {
            return currenthealth;
        }

        public int MaxHealth()
        {
            return maxhealth;
        }

        public bool IsMoving()
        {
            return isMoving;
        }
        
        public bool IsAttacking()
        {
            return isAttacking;
        }
    }
}
