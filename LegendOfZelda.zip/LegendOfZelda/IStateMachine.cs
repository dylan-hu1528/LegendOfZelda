﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game1
{
    interface IStateMachine
    {
        void SetSprite();

        void SetDirection(string dir);

        void SetColor(string col);

        void SetWeapon(string weap);

        void SetShield(string shi);

        void SetHealth(int num);

        void SetIsMoving(bool tf);
    }
}
