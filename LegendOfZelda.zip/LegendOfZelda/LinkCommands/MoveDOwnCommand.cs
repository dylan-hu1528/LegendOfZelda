﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game1.LinkCommands
{
    class MoveDownCommand : ICommand
    {
        private IPlayer Player { get; set; }

        public MoveDownCommand(IPlayer player)
        {
            Player = player;
        }
        public void Execute()
        {
            if (!Player.GetStateMachine().IsAttacking())
            {
                Player.SetDirection("down");
                Player.SetIsMoving(true);
            }
        }
    }
}
