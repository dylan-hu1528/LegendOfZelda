﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game1.LinkCommands
{
    class IdleCommand : ICommand
    {
        IPlayer Player { get; set; }

        public IdleCommand(IPlayer player)
        {
            Player = player;
        }
        public void Execute()
        {
            Player.SetIsMoving(false);
        }
    }
}
