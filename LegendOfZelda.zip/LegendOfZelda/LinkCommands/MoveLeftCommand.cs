﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game1.LinkCommands
{
    class MoveLeftCommand : ICommand
    {
        private IPlayer Player { get; set; }

        public MoveLeftCommand(IPlayer player)
        {
            Player = player;
        }
        public void Execute()
        {
            if (!Player.GetStateMachine().IsAttacking())
            {
                Player.SetDirection("left");
                Player.SetIsMoving(true);
            }
        }
    }
}
