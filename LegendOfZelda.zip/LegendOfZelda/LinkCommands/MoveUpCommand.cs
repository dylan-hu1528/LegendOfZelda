﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game1.LinkCommands
{
    class MoveUpCommand : ICommand
    {
        private IPlayer Player { get; set; }

        public MoveUpCommand(IPlayer player)
        {
            Player = player;
        }
        public void Execute()
        {
            if (!Player.GetStateMachine().IsAttacking())
            {
                Player.SetDirection("up");
                Player.SetIsMoving(true);
            }
        }
    }
}
