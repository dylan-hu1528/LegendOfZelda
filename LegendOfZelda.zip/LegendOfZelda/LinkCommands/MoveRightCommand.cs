﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game1.LinkCommands
{
    class MoveRightCommand : ICommand
    {
        private IPlayer Player { get; set; }

        public MoveRightCommand(IPlayer player)
        {
            Player = player;
        }
        public void Execute()
        {
            if (!Player.GetStateMachine().IsAttacking())
            {
                Player.SetDirection("right");
                Player.SetIsMoving(true);
            }
        }
    }
}
