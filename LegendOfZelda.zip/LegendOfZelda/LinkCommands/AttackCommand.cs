﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game1.LinkCommands
{
    class AttackCommand : ICommand
    {
        IPlayer Player { get; set; }

        public AttackCommand(IPlayer player)
        {
            Player = player;
        }
        public void Execute()
        {
            Player.SetIsMoving(false);
            Player.SetIsAttacking();
        }
    }
}
