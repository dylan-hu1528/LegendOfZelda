﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game1.LinkCommands
{
    class TakeDamageCommand : ICommand
    {
        IPlayer Player { get; set; }

        public TakeDamageCommand(IPlayer player)
        {
            Player = player;
        }
        public void Execute()
        {
            Player.SetHealth(-1);
        }
    }
}
