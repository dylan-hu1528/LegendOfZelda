﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game1
{
    //Rupee (flashing blue & gold)
    class Rupee : IItem
    {
        Rectangle sourceRectangle;
        Rectangle destinationRectangle;

        // Generate a random number between two numbers  
        //public void RandomX()
        //{
        //    Random random = new Random();
        //    Xr = random.Next(0, 800);
        //}

        //public void RandomY()
        //{
        //    Random random = new Random();
        //    Yr = random.Next(0, 480);
        //}

        public Texture2D Texture { get; set; }
        private int currentFrame = 0;
        private int totalFrames = 3;
        int delay;

        public Rupee(Texture2D texture)
        {
            Texture = texture;
        }

        public void Update(GameTime gameTime)
        {
            if (delay % 10 == 0)
            {
                currentFrame++;
                if (currentFrame == totalFrames)
                    currentFrame = 0;
            }
            delay++;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            if (currentFrame == 0)
            {
                sourceRectangle = new Rectangle(379, 349, 17, 29);
                destinationRectangle = new Rectangle(400, 240, 20, 36);
            }
            else if (currentFrame == 1)
            {
                sourceRectangle = new Rectangle(426, 349, 15, 29);
                destinationRectangle = new Rectangle(400, 240, 20, 36);
            }
            else if (currentFrame == 2)
            {
                sourceRectangle = new Rectangle(379, 349, 17, 29);
                destinationRectangle = new Rectangle(400, 240, 20, 36);
            }

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }
    }
}
