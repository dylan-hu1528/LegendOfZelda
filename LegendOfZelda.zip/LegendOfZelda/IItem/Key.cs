﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game1
{
    //Key (no animation)
    class Key : IItem
    {
        public Texture2D Texture { get; set; }

        public Key(Texture2D texture)
        {
            this.Texture = texture;
        }

        public void Update(GameTime gameTime)
        {
        }

        public void Draw(SpriteBatch spriteBatch)
        {

            Rectangle sourceRectangle = new Rectangle(1023, 62, 17, 27);
            Rectangle destinationRectangle = new Rectangle(400, 240, 17, 27);

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }
    }
}
