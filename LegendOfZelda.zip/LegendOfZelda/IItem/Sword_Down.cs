﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game1
{
    //sword thrown DOWN (animated)
    class Sword_Down : IItem
    {
        Rectangle sourceRectangle;
        Rectangle destinationRectangle;
        Rectangle position;

        public Texture2D Texture { get; set; }
        private int Yposition;
        private int previousFrameTime = 0;

        private int currentFrame = 0;
        private int totalFrames = 4;

        public Sword_Down(Texture2D texture)
        {
            Texture = texture;
        }

        public void Update(GameTime gameTime)
        {
            previousFrameTime += gameTime.ElapsedGameTime.Milliseconds;
            if (previousFrameTime > 20)
            {
                previousFrameTime -= 20;
                currentFrame++;
                if (Yposition == 400)
                {
                    Yposition -= 10;
                }
                if (Yposition == 0)
                {
                    Yposition += 10;
                }
                Yposition++;
                if (currentFrame == totalFrames)
                    currentFrame = 0;
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            position.Y += Yposition;

            if (currentFrame == 0)
            {
                sourceRectangle = new Rectangle(4, 302, 15, 29);
                destinationRectangle = new Rectangle(400, Yposition, 20, 34);
            }
            else if (currentFrame == 1)
            {
                sourceRectangle = new Rectangle(4, 349, 15, 29);
                destinationRectangle = new Rectangle(400, Yposition, 20, 34);
            }
            else if (currentFrame == 2)
            {
                sourceRectangle = new Rectangle(4, 396, 15, 29);
                destinationRectangle = new Rectangle(400, Yposition, 20, 34);
            }
            else if (currentFrame == 3)
            {
                sourceRectangle = new Rectangle(4, 443, 15, 29);
                destinationRectangle = new Rectangle(400, Yposition, 20, 34);
            }

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }
    }
}
