﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game1
{
    //Bow (no animation)
    class Bow : IItem
    {
        public Texture2D Texture { get; set; }

        public Bow(Texture2D texture)
        {
            this.Texture = texture;
        }

        public void Update(GameTime gameTime)
        {
        }

        public void Draw(SpriteBatch spriteBatch)
        {

            Rectangle sourceRectangle = new Rectangle(1086, 0, 16, 27);
            Rectangle destinationRectangle = new Rectangle(400, 240, 16, 27);

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }
    }
}
