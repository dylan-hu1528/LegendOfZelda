﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace Game1
{
    //Create an interface for any and all items, IItem
    public interface IItem
    {
        //update and draw methods go here
        void Update(GameTime gameTime);
        void Draw(SpriteBatch spriteBatch);
    }
}
