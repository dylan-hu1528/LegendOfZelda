﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game1
{
    //sword thrown Left (animated)
    class Sword_Left : IItem
    {
        Rectangle sourceRectangle;
        Rectangle destinationRectangle;

        Rectangle position;
        public Texture2D Texture { get; set; }
        private int Xposition = 800;
        private int previousFrameTime = 0;

        private int currentFrame;
        private int totalFrames;

        public Sword_Left(Texture2D texture)
        {
            Texture = texture;
            currentFrame = 0;
            totalFrames = 4;
        }

        public void Update(GameTime gameTime)
        {
            previousFrameTime += gameTime.ElapsedGameTime.Milliseconds;
            if (previousFrameTime > 30)
            {
                previousFrameTime -= 30;
                currentFrame++;
                if (Xposition == 0)
                {
                    Xposition = 800;
                }
                if (Xposition == 800)
                {
                    Xposition -= 10;
                }
                Xposition--;
                if (currentFrame == totalFrames)
                    currentFrame = 0;
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            position.X += Xposition;

            if (currentFrame == 0)
            {
                sourceRectangle = new Rectangle(45, 309, 29, 14);
                destinationRectangle = new Rectangle(Xposition, 240, 32, 14);
            }
            else if (currentFrame == 1)
            {
                sourceRectangle = new Rectangle(45, 356, 29, 14);
                destinationRectangle = new Rectangle(Xposition, 240, 32, 14);
            }
            else if (currentFrame == 2)
            {
                sourceRectangle = new Rectangle(45, 404, 29, 13);
                destinationRectangle = new Rectangle(Xposition, 240, 32, 14);
            }
            else if (currentFrame == 3)
            {
                sourceRectangle = new Rectangle(45, 449, 29, 15);
                destinationRectangle = new Rectangle(Xposition, 240, 32, 14);
            }

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }

    }
}
