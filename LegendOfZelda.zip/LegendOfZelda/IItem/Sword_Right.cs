﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game1
{
    //sword thrown Right (animated)
    class Sword_Right : IItem
    {
        Rectangle sourceRectangle;
        Rectangle destinationRectangle;
        Rectangle position;

        public Texture2D Texture { get; set; }
        private int Xposition;
        private int previousFrameTime = 0;

        private int currentFrame = 0;
        private int totalFrames = 4;

        public Sword_Right(Texture2D texture)
        {
            Texture = texture;
        }

        public void Update(GameTime gameTime)
        {
            previousFrameTime += gameTime.ElapsedGameTime.Milliseconds;
            if (previousFrameTime > 30)
            {
                previousFrameTime -= 30;
                currentFrame++;
                if (Xposition == 800)
                {
                    Xposition = 0;
                }
                if (Xposition == 0)
                {
                    Xposition += 10;
                }
                Xposition++;
                if (currentFrame == totalFrames)
                    currentFrame = 0;
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            position.X += Xposition;

            if (currentFrame == 0)
            {
                sourceRectangle = new Rectangle(139, 309, 27, 14);
                destinationRectangle = new Rectangle(Xposition, 240, 32, 14);
            }
            else if (currentFrame == 1)
            {
                sourceRectangle = new Rectangle(139, 356, 27, 14);
                destinationRectangle = new Rectangle(Xposition, 240, 32, 14);
            }
            else if (currentFrame == 2)
            {
                sourceRectangle = new Rectangle(139, 404, 27, 13);
                destinationRectangle = new Rectangle(Xposition, 240, 32, 14);
            }
            else if (currentFrame == 3)
            {
                sourceRectangle = new Rectangle(139, 449, 27, 15);
                destinationRectangle = new Rectangle(Xposition, 240, 32, 14);
            }

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }
    }
}
