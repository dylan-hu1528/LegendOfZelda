﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game1
{
    //Fairy (flying)
    class Fairy : IItem
    {
        Rectangle sourceRectangle;
        Rectangle destinationRectangle;

        public Texture2D Texture { get; set; }
        private int currentFrame = 0;
        private int totalFrames = 3;
        int delay;

        public Fairy(Texture2D texture)
        {
            Texture = texture;
        }

        public void Update(GameTime gameTime)
        {
            if (delay % 10 == 0)
            {
                currentFrame++;
                if (currentFrame == totalFrames)
                    currentFrame = 0;
            }
            delay++;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            if (currentFrame == 0)
            {
                sourceRectangle = new Rectangle(836, 62, 16, 27);
                destinationRectangle = new Rectangle(400, 240, 32, 54);
            }
            else if (currentFrame == 1)
            {
                sourceRectangle = new Rectangle(774, 62, 16, 27);
                destinationRectangle = new Rectangle(400, 240, 32, 54);
            }
            else if (currentFrame == 2)
            {
                sourceRectangle = new Rectangle(836, 62, 16, 27);
                destinationRectangle = new Rectangle(400, 240, 32, 54);
            }

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }
    }
}
