﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game1
{
    //Bomb (no animation)
    class Bomb : IItem
    {
        public Texture2D Texture { get; set; }

        public Bomb(Texture2D texture)
        {
            this.Texture = texture;
        }

        public void Update(GameTime gameTime)
        {
        }

        public void Draw(SpriteBatch spriteBatch)
        {

            Rectangle sourceRectangle = new Rectangle(900, 0, 15, 25);
            Rectangle destinationRectangle = new Rectangle(400, 240, 15, 25);

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }
    }
}
