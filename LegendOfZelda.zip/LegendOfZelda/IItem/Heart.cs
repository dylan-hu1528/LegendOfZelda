﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game1
{
    //Heart (flashing red and blue)
    class Heart : IItem
    {
        Rectangle sourceRectangle;
        Rectangle destinationRectangle;

        public Texture2D Texture { get; set; }
        private int currentFrame = 0;
        private int totalFrames = 3;
        int delay;

        public Heart(Texture2D texture)
        {
            Texture = texture;
        }

        public void Update(GameTime gameTime)
        {
            if (delay % 10 == 0)
            {
                currentFrame++;
                if (currentFrame == totalFrames)
                    currentFrame = 0;
            }
            delay++;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            if (currentFrame == 0)
            {
                sourceRectangle = new Rectangle(379, 309, 15, 16);
                destinationRectangle = new Rectangle(400, 240, 30, 32);
            }
            else if (currentFrame == 1)
            {
                sourceRectangle = new Rectangle(426, 309, 15, 16);
                destinationRectangle = new Rectangle(400, 240, 30, 32);
            }
            else if (currentFrame == 2)
            {
                sourceRectangle = new Rectangle(379, 309, 15, 16);
                destinationRectangle = new Rectangle(400, 240, 30, 32);
            }

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }
    }
}
