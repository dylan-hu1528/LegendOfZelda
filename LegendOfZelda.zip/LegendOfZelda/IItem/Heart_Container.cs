﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game1
{
    //Heart Container (no animation)
    class Heart_Container : IItem
    {
        public Texture2D Texture { get; set; }

        public Heart_Container(Texture2D texture)
        {
            this.Texture = texture;
        }

        public void Update(GameTime gameTime)
        {
        }

        public void Draw(SpriteBatch spriteBatch)
        {

            Rectangle sourceRectangle = new Rectangle(956, 62, 24, 24);
            Rectangle destinationRectangle = new Rectangle(400, 240, 24, 24);

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }
    }
}
