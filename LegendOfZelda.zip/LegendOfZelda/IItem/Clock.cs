﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game1
{
    //Clock (no animation)
    class Clock : IItem
    {
        public Texture2D Texture { get; set; }

        public Clock(Texture2D texture)
        {
            this.Texture = texture;
        }

        public void Update(GameTime gameTime)
        {
        }

        public void Draw(SpriteBatch spriteBatch)
        {

            Rectangle sourceRectangle = new Rectangle(611, 256, 19, 28);
            Rectangle destinationRectangle = new Rectangle(400, 240, 19, 28);

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }
    }
}
