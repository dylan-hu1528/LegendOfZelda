﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game1
{
    //Triforce (flashing blue and yellow)
    class Triforce : IItem
    {
        Rectangle sourceRectangle;
        Rectangle destinationRectangle;

        public Texture2D Texture { get; set; }
        private int currentFrame = 0;
        private int totalFrames = 3;
        int delay;

        public Triforce(Texture2D texture)
        {
            Texture = texture;
        }

        public void Update(GameTime gameTime)
        {
            if (delay % 10 == 0)
            {
                currentFrame++;
                if (currentFrame == totalFrames)
                    currentFrame = 0;
            }
            delay++;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            if (currentFrame == 0)
            {
                sourceRectangle = new Rectangle(565, 448, 20, 19);
                destinationRectangle = new Rectangle(400, 240, 30, 32);
            }
            else if (currentFrame == 1)
            {
                sourceRectangle = new Rectangle(520, 448, 18, 19);
                destinationRectangle = new Rectangle(400, 240, 30, 32);
            }
            else if (currentFrame == 2)
            {
                sourceRectangle = new Rectangle(565, 448, 20, 19);
                destinationRectangle = new Rectangle(400, 240, 30, 32);
            }

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }

    }
}
