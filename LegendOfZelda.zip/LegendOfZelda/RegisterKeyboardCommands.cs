﻿using Microsoft.Xna.Framework.Input;

namespace Game1
{
    class RegisterKeyboardCommands
    {
        KeyboardController kc;
        Game1 Game { get; set; }

        public RegisterKeyboardCommands(KeyboardController keyControl, Game1 game)
        {
            kc = keyControl;
            Game = game;
            RegisterKeysAndCommands();
        }

        public void RegisterKeysAndCommands()
        {
            // General commands
            kc.RegisterCommand(Keys.Q, new GeneralCommands.QuitCommand(Game));
            kc.RegisterCommand(Keys.R, new GeneralCommands.ResetCommand(Game));

            // Link commands
            kc.RegisterLinkCommand(Keys.W, new LinkCommands.MoveUpCommand(Game.GetPlayer()));
            kc.RegisterLinkCommand(Keys.S, new LinkCommands.MoveDownCommand(Game.GetPlayer()));
            kc.RegisterLinkCommand(Keys.A, new LinkCommands.MoveLeftCommand(Game.GetPlayer()));
            kc.RegisterLinkCommand(Keys.D, new LinkCommands.MoveRightCommand(Game.GetPlayer()));
            kc.RegisterLinkCommand(Keys.Up, new LinkCommands.MoveUpCommand(Game.GetPlayer()));
            kc.RegisterLinkCommand(Keys.Down, new LinkCommands.MoveDownCommand(Game.GetPlayer()));
            kc.RegisterLinkCommand(Keys.Left, new LinkCommands.MoveLeftCommand(Game.GetPlayer()));
            kc.RegisterLinkCommand(Keys.Right, new LinkCommands.MoveRightCommand(Game.GetPlayer()));
            kc.RegisterLinkCommand(Keys.E, new LinkCommands.TakeDamageCommand(Game.GetPlayer()));
            kc.RegisterLinkCommand(Keys.Z, new LinkCommands.AttackCommand(Game.GetPlayer()));
            kc.RegisterLinkCommand(Keys.N, new LinkCommands.AttackCommand(Game.GetPlayer()));

            // Item 
            kc.RegisterItemCommand(Keys.I, new SetNextItemCommand(Game));
            kc.RegisterItemCommand(Keys.U, new SetPreviousItemCommand(Game));

            // Enemy commands
            kc.RegisterEnemyCommand(Keys.O, new SetEnemyPreviousCommand(Game));
            kc.RegisterEnemyCommand(Keys.P, new SetEnemyNextCommand(Game));

        }
    }
}
