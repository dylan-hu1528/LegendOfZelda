﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;

namespace Game1
{
    /// <summary>
    /// This is the main type for your game.
    /// Full playthrough of the game
    /// https://www.youtube.com/watch?v=6g2vk8Gudqs
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        KeyboardController kc;
        RegisterKeyboardCommands registerCommands;
        private IPlayer Player { get; set; }

        public TextureLoader TextureLoader { get; set; }

        List<IItem> items;
        List<IEnemy> enemies;
        List<IProjectile> fireballs;
        List<IProjectile> linkProjectiles;

        public int currentEnemy = 0, currentItem = 0;
        public int delay = 0;

        public Vector2 enemyPos;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        public void Reset()
        {
            Initialize();
            LoadContent();
            currentEnemy = 0;
            currentItem = 0;
        }

        public IPlayer GetPlayer()
        {
            return Player;
            
        }

        public void AddLinkProjectile(IProjectile proj)
        {
            linkProjectiles.Add(proj);
        }

        public bool IsOutOfBounds(IProjectile proj)
        {
            if (proj.GetLocation().X < 0 || proj.GetLocation().X > 800 || proj.GetLocation().Y < 0 || proj.GetLocation().Y > 480)
                return true;
            return false;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            TextureLoader = new TextureLoader(this);
            Player = new Link(this);
            kc = new KeyboardController(this);
            registerCommands = new RegisterKeyboardCommands(kc, this);

            enemies = new List<IEnemy>();
            fireballs = new List<IProjectile>();
            linkProjectiles = new List<IProjectile>();
            enemyPos = new Vector2(600, 200);

            items = new List<IItem>();

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            enemies.Add(new DragonEnemy(Content.Load<Texture2D>("images/dragonboi"), 1, 2, enemyPos));
            enemies.Add(new BatEnemy(Content.Load<Texture2D>("images/bat-sprite"), 1, 2, enemyPos));
            enemies.Add(new GelEnemy(Content.Load<Texture2D>("images/gel-sprite"), 1, 2, enemyPos));
            enemies.Add(new SkeletonEnemy(Content.Load<Texture2D>("images/stalfos-sprite"), 1, 2, enemyPos));
            enemies.Add(new BlueGoriya(Content.Load<Texture2D>("images/goriya-blue-sprite"), 1, 2, enemyPos));
            enemies.Add(new RedGoriya(Content.Load<Texture2D>("images/goriya-red-sprite"), 1, 2, enemyPos));
            enemies.Add(new SnakeLeft(Content.Load<Texture2D>("images/snake-face-left-sprite"), 1, 2, enemyPos));
            enemies.Add(new SnakeRight(Content.Load<Texture2D>("images/snake-face-right-sprite"), 1, 2, enemyPos));
            enemies.Add(new TrapEnemy(Content.Load<Texture2D>("images/trap-sprite"), 1, 1, enemyPos));
            enemies.Add(new HandLeft(Content.Load<Texture2D>("images/hand-facing-left-sprite"), 1, 2, enemyPos));
            enemies.Add(new HandRight(Content.Load<Texture2D>("images/hand-facing-right-sprite"), 1, 2, enemyPos));
            fireballs.Add(new FireBall(Content.Load<Texture2D>("images/fire-pellet"), enemyPos, -1));
            fireballs.Add(new FireBall(Content.Load<Texture2D>("images/fire-pellet"), enemyPos, 0));
            fireballs.Add(new FireBall(Content.Load<Texture2D>("images/fire-pellet"), enemyPos, 1));

            items.Add(new Arrow(Content.Load<Texture2D>("items/Picture1")));
            items.Add(new Bomb(Content.Load<Texture2D>("items/Picture1")));
            items.Add(new Bow(Content.Load<Texture2D>("items/Picture1")));
            items.Add(new Clock(Content.Load<Texture2D>("items/Picture1")));
            items.Add(new Compass(Content.Load<Texture2D>("items/Picture1")));
            items.Add(new Fairy(Content.Load<Texture2D>("items/Picture1")));
            items.Add(new Heart(Content.Load<Texture2D>("items/Picture1")));
            items.Add(new Heart_Container(Content.Load<Texture2D>("items/Picture1")));
            items.Add(new Key(Content.Load<Texture2D>("items/Picture1")));
            items.Add(new Map(Content.Load<Texture2D>("items/Picture1")));
            items.Add(new Rupee(Content.Load<Texture2D>("items/Picture1")));
            items.Add(new Triforce(Content.Load<Texture2D>("items/Picture1")));

        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            enemies[currentEnemy].Update();

            for(int i = linkProjectiles.Count - 1; i >= 0; i--)
            {
                linkProjectiles[i].Update();
                if (linkProjectiles[i].DurationCounter() == 0 || IsOutOfBounds(linkProjectiles[i]))
                {
                    if(linkProjectiles[i].GetType() == typeof(IProjectiles.Sword))
                    {
                        Vector2 spawnLocation = linkProjectiles[i].GetLocation();
                        linkProjectiles.Add(new IProjectiles.SwordBurst(TextureLoader.GetTexture("swordburstupleft"), spawnLocation, "upleft"));
                        linkProjectiles.Add(new IProjectiles.SwordBurst(TextureLoader.GetTexture("swordburstupright"), spawnLocation, "upright"));
                        linkProjectiles.Add(new IProjectiles.SwordBurst(TextureLoader.GetTexture("swordburstdownleft"), spawnLocation, "downleft"));
                        linkProjectiles.Add(new IProjectiles.SwordBurst(TextureLoader.GetTexture("swordburstdownright"), spawnLocation, "downright"));
                    }
                    linkProjectiles.RemoveAt(i);
                }
            }

            linkProjectiles.TrimExcess();

            if (currentEnemy == 0)
            {
                foreach (IProjectile proj in fireballs)
                {
                    proj.Update();
                }
                if (delay % 300 == 0)
                {
                    fireballs[0] = new FireBall(Content.Load<Texture2D>("images/fire-pellet"), enemyPos, -1);
                    fireballs[1] = new FireBall(Content.Load<Texture2D>("images/fire-pellet"), enemyPos, 0);
                    fireballs[2] = new FireBall(Content.Load<Texture2D>("images/fire-pellet"), enemyPos, 1);
                }
            }
            delay++;

            items[currentItem].Update(gameTime);
            
            kc.Update();
            Player.Update();

            base.Update(gameTime);

        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            enemies[currentEnemy].Draw(spriteBatch);
            if (currentEnemy == 0)
            {
                foreach (IProjectile proj in fireballs)
                {
                    proj.Draw(spriteBatch);
                }
            }

            foreach (IProjectile proj in linkProjectiles)
            {
                proj.Draw(spriteBatch);
            }

            items[currentItem].Draw(spriteBatch);

            Player.Draw(spriteBatch);

            base.Draw(gameTime);
        }
    }
}
