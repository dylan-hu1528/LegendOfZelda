namespace Game1
{
    class SetEnemyPreviousCommand : ICommand
    {
        private Game1 myGame;

        public SetEnemyPreviousCommand(Game1 game)
        {
            myGame = game;
        }

        public void Execute()
        {
            myGame.currentEnemy--;
            if (myGame.currentEnemy < 0)
                myGame.currentEnemy = 10;
        }
    }
}