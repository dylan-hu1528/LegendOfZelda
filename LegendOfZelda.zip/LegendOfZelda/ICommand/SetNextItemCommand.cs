﻿namespace Game1
{
    class SetNextItemCommand : ICommand
    {
        private Game1 myGame;

        public SetNextItemCommand(Game1 game)
        {
            myGame = game;
        }

        public void Execute()
        {
            myGame.currentItem = (myGame.currentItem + 1) % 12;
        }
    }
}
