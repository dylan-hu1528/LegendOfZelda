﻿namespace Game1
{
    class SetPreviousItemCommand : ICommand
    {
        private Game1 myGame;

        public SetPreviousItemCommand(Game1 game)
        {
            myGame = game;
        }

        public void Execute()
        {
            myGame.currentItem--;
            if(myGame.currentItem < 0)
            {
                myGame.currentItem = 11;
            }
        }
    }
}
