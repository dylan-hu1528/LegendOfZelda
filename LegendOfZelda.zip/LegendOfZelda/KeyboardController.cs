﻿using System.Collections.Generic;
using Microsoft.Xna.Framework.Input;

namespace Game1
{
    class KeyboardController : IController
    {
        private Dictionary<Keys, ICommand> controllerMappings, linkKeyMappings, itemKeyMappings, enemyKeyMappings;
        private Dictionary<string, ICommand> otherCommands;
        private List<Keys> linkBoundKeys;
        private Game1 Game { get; set; }

        private KeyboardState curState, prevState;

        public KeyboardController(Game1 game)
        {
            controllerMappings = new Dictionary<Keys, ICommand>();

            linkKeyMappings = new Dictionary<Keys, ICommand>();
            itemKeyMappings = new Dictionary<Keys, ICommand>();
            enemyKeyMappings = new Dictionary<Keys, ICommand>();
            otherCommands = new Dictionary<string, ICommand>();
            linkBoundKeys = new List<Keys>();
            Game = game;
            curState = Keyboard.GetState();
            prevState = curState;
            otherCommands.Add("idle", new LinkCommands.IdleCommand(Game.GetPlayer()));
        }

        public void RegisterCommand(Keys key, ICommand command)
        {
            controllerMappings.Add(key, command);
        }

        public void RegisterLinkCommand(Keys key, ICommand command)
        {
            linkKeyMappings.Add(key, command);
            linkBoundKeys.Add(key);
        }

        public void RegisterItemCommand(Keys key, ICommand command)
        {
            itemKeyMappings.Add(key, command);
        }

        public void RegisterEnemyCommand(Keys key, ICommand command)
        {
            enemyKeyMappings.Add(key, command);
        }

        public void Update()
        {
            curState = Keyboard.GetState();

            Game.GetPlayer().GetStateMachine().SetSprite();

            Keys[] pressedKeys = Keyboard.GetState().GetPressedKeys();

            foreach (Keys key in pressedKeys)
            {
                if (controllerMappings.ContainsKey(key))
                {
                    controllerMappings[key].Execute();

                }
                if (linkKeyMappings.ContainsKey(key))
                {
                    linkKeyMappings[key].Execute();
                }
            }

            if(curState.IsKeyDown(Keys.U) && prevState.IsKeyUp(Keys.U))
            {
                itemKeyMappings[Keys.U].Execute();
            }
            if (curState.IsKeyDown(Keys.I) && prevState.IsKeyUp(Keys.I))
            {
                itemKeyMappings[Keys.I].Execute();
            }

            if (curState.IsKeyDown(Keys.O) && prevState.IsKeyUp(Keys.O))
            {
                enemyKeyMappings[Keys.O].Execute();
            }
            if (curState.IsKeyDown(Keys.P) && prevState.IsKeyUp(Keys.P))
            {
                enemyKeyMappings[Keys.P].Execute();
            }

            bool allKeysUp = true;
            foreach (Keys key in linkBoundKeys)
            {
                foreach (Keys pressedkey in pressedKeys)
                {
                    if (key == pressedkey)
                    {
                        allKeysUp = false;
                    }
                }
            }
            if (allKeysUp)
            {
                otherCommands["idle"].Execute();
            }

            prevState = curState;
        }
    }
}