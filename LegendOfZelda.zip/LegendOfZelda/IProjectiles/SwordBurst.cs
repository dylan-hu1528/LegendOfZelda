﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game1.IProjectiles
{
    class SwordBurst : IProjectile
    {
        private Texture2D Texture { get; set; }
        private Vector2 Location { get; set; }
        private string direction;

        private int currentframe;
        private int width, height;

        private int durationcounter;

        private const int TOTAL_FRAMES = 4, SCALE = 2;

        public SwordBurst(Texture2D texture, Vector2 location, string dir)
        {
            Texture = texture;
            Location = location;
            direction = dir;
            currentframe = 0;
            width = Texture.Width / TOTAL_FRAMES;
            height = Texture.Height;
            durationcounter = 10;
        }

        public int DurationCounter()
        {
            return durationcounter;
        }

        public Vector2 GetLocation()
        {
            return Location;
        }

        public void Update()
        {
            currentframe = (currentframe + 1) % TOTAL_FRAMES;

            durationcounter--;

            switch (direction)
            {
                case "upleft":
                    Location = new Vector2(Location.X - 3, Location.Y - 3);
                    break;
                case "downleft":
                    Location = new Vector2(Location.X - 3, Location.Y + 3);
                    break;
                case "upright":
                    Location = new Vector2(Location.X + 3, Location.Y - 3);
                    break;
                case "downright":
                    Location = new Vector2(Location.X + 3, Location.Y + 3);
                    break;
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            Rectangle sourcerectangle = new Rectangle(currentframe * width, 0, width, height);
            Rectangle destinationrectangle = new Rectangle((int)Location.X, (int)Location.Y, width * SCALE, height * SCALE);

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationrectangle, sourcerectangle, Color.White);
            spriteBatch.End();
        }
    }
}
