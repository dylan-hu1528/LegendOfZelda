﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace Game1
{
    //Create an interface for any and all items, IItem
    public interface IProjectile
    {
        int DurationCounter();
        Vector2 GetLocation();
        //update and draw methods go here
        void Update();
        void Draw(SpriteBatch spriteBatch);
    }
}