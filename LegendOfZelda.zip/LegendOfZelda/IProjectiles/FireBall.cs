﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game1
{
    class FireBall : IProjectile
    {
        public Texture2D Texture { get; set; }
        private int locationY, locationX, velocityY, durationcounter;

        public FireBall(Texture2D texture, Vector2 location, int Yvelocity)
        {
            Texture = texture;
            locationY = (int)location.Y;
            locationX = (int)location.X;
            velocityY = Yvelocity;
            durationcounter = 50;
        }

        public int DurationCounter()
        {
            return durationcounter;
        }

        public Vector2 GetLocation()
        {
            return new Vector2(locationX, locationY);
        }

        public void Update()
        {
            durationcounter--;
            if (velocityY == -1)
                locationY -= 2;
            else if (velocityY == 1)
                locationY += 2;
            locationX -= 4;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            int width = Texture.Width;
            int height = Texture.Height;

            Rectangle sourceRectangle = new Rectangle(0, 0, width, height);
            Rectangle destinationRectangle = new Rectangle(locationX, locationY, 2 * width, 2 * height);


            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationRectangle, sourceRectangle, Color.White);
            spriteBatch.End();
        }

    }

}
