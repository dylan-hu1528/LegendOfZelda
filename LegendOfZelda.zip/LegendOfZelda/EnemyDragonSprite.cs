using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint2
{
    class EnemyDragonSprite : IEnemy
    {
        private Game1 myGame;
        public EnemyDragonSprite(Game1 game)
        {
            this.myGame = game;
        }

        public void Update()
        {
            if (this.myGame.elapsed >= this.myGame.delay)
            {
                if (this.myGame.frames >= 2)
                {
                    this.myGame.frames = 0;
                }
                else
                {
                    this.myGame.frames++;
                }
                this.myGame.elapsed = 0;
            }

            this.myGame.sourceRectXVal = 146 * this.myGame.frames;
            this.myGame.destRectYVal++;
            if (this.myGame.destRectYVal == 400)
            {
                this.myGame.destRectYVal = 0;
            }

        }
    }
}
