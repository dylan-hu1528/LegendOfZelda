﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;

namespace Game1.LinkSprites
{
    class LinkAttackDownSprite : ISprite
    {
        private Texture2D Texture { get; set; }
        private int currentframe, delay;
        private int width, height;

        private const int TOTAL_FRAMES = 4, SCALE = 2;

        public LinkAttackDownSprite(Texture2D texture)
        {
            Texture = texture;
            currentframe = 0;
            delay = 0;
            width = Texture.Width / TOTAL_FRAMES;
            height = Texture.Height;
        }

        public void Update()
        {
            delay = (delay + 1) % 5;
            if (delay == 0)
                currentframe = (currentframe + 1) % TOTAL_FRAMES;
        }

        public void Draw(SpriteBatch spriteBatch, Vector2 location)
        {
            Rectangle sourcerectangle = new Rectangle(currentframe * width, 0, width, height);
            Rectangle destinationrectangle = new Rectangle((int)location.X, (int)location.Y, width * SCALE, height * SCALE);

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationrectangle, sourcerectangle, Color.White);
            spriteBatch.End();
        }
    }
}
