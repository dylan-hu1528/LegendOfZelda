﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;

namespace Game1.LinkSprites
{
    class HurtLinkAttackRightSprite : ISprite
    {
        private Texture2D Texture { get; set; }
        private List<Color> hurtcolors;
        private int currentframe, delay;
        private int hurtdelay, colorindex;
        private int width, height;

        private const int TOTAL_FRAMES = 4, SCALE = 2;

        public HurtLinkAttackRightSprite(Texture2D texture)
        {
            Texture = texture;
            width = Texture.Width / TOTAL_FRAMES;
            height = Texture.Height;
            currentframe = 0;
            delay = 0;

            hurtcolors = new List<Color>
            {
                Color.White,
                Color.Cyan,
                Color.PaleVioletRed,
                Color.Blue
            };
            hurtdelay = 0;
            colorindex = 0;
        }

        public void Update()
        {
            delay = (delay + 1) % 5;
            if (delay == 0)
                currentframe = (currentframe + 1) % TOTAL_FRAMES;

            hurtdelay = (hurtdelay + 1) % 3;
            if (hurtdelay == 0)
                colorindex = (colorindex + 1) % 4;
        }

        public void Draw(SpriteBatch spriteBatch, Vector2 location)
        {
            Rectangle sourcerectangle = new Rectangle(currentframe * width, 0, width, height);
            Rectangle destinationrectangle = new Rectangle((int)location.X, (int)location.Y, width * SCALE, height * SCALE);

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationrectangle, sourcerectangle, hurtcolors[colorindex]);
            spriteBatch.End();
        }
    }
}
