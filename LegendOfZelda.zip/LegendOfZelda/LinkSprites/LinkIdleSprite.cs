﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;

namespace Game1.LinkSprites
{
    class LinkIdleSprite : ISprite
    {
        private Texture2D Texture { get; set; }
        private int width, height;

        private const int TOTAL_FRAMES = 2, SCALE = 2;

        public LinkIdleSprite(Texture2D texture)
        {
            Texture = texture;
            width = Texture.Width / TOTAL_FRAMES;
            height = Texture.Height;
        }

        public void Update()
        {
            // don't need an update
        }

        public void Draw(SpriteBatch spriteBatch, Vector2 location)
        {
            Rectangle sourcerectangle = new Rectangle(0, 0, width, height);
            Rectangle destinationrectangle = new Rectangle((int)location.X, (int)location.Y, width * SCALE, height * SCALE);

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationrectangle, sourcerectangle, Color.White);
            spriteBatch.End();
        }
    }
}
