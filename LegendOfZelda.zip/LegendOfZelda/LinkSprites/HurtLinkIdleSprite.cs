﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;

namespace Game1.LinkSprites
{
    class HurtLinkIdleSprite : ISprite
    {
        private Texture2D Texture { get; set; }
        private List<Color> hurtcolors;
        private int colorindex, delay;
        private int width, height;

        private const int TOTAL_FRAMES = 2, SCALE = 2;

        public HurtLinkIdleSprite(Texture2D texture)
        {
            Texture = texture;
            width = Texture.Width / TOTAL_FRAMES;
            height = Texture.Height;

            hurtcolors = new List<Color>
            {
                Color.White,
                Color.Cyan,
                Color.PaleVioletRed,
                Color.Blue
            };
            colorindex = 0;
            delay = 0;
        }

        public void Update()
        {
            // only used when hurt
            delay = (delay + 1) % 3;
            if (delay == 0)
                colorindex = (colorindex + 1) % 4;

        }

        public void Draw(SpriteBatch spriteBatch, Vector2 location)
        {
            Rectangle sourcerectangle = new Rectangle(0, 0, width, height);
            Rectangle destinationrectangle = new Rectangle((int)location.X, (int)location.Y, width * SCALE, height * SCALE);

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationrectangle, sourcerectangle, hurtcolors[colorindex]);
            spriteBatch.End();
        }
    }
}
