﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Game1.LinkSprites
{
    class LinkAttackLeftSprite : ISprite
    {
        private Texture2D Texture { get; set; }
        private int currentframe, delay;
        private int width, height;

        private const int TOTAL_FRAMES = 4, SCALE = 2, LINK_SIZE = 16;

        public LinkAttackLeftSprite(Texture2D texture)
        {
            Texture = texture;
            width = Texture.Width / TOTAL_FRAMES;
            height = Texture.Height;
            currentframe = 0;
            delay = 0;
        }

        public void Update()
        {
            delay = (delay + 1) % 5;
            if (delay == 0)
                currentframe = (currentframe + 1) % TOTAL_FRAMES;
        }

        public void Draw(SpriteBatch spriteBatch, Vector2 location)
        {
            Rectangle sourcerectangle = new Rectangle(currentframe * width, 0, width, height);
            Rectangle destinationrectangle = new Rectangle((int)location.X - (width - LINK_SIZE) * SCALE, (int)location.Y, width * SCALE, height * SCALE);

            spriteBatch.Begin();
            spriteBatch.Draw(Texture, destinationrectangle, sourcerectangle, Color.White);
            spriteBatch.End();
        }
    }
}
