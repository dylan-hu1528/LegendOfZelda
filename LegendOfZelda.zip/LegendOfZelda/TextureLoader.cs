﻿using System.Collections.Generic;
using Microsoft.Xna.Framework.Graphics;

namespace Game1
{
    public class TextureLoader
    {
        private Game1 game;
        private Dictionary<string, Texture2D> Textures { get; set; }

        public TextureLoader(Game1 game)
        {
            this.game = game;
            Textures = new Dictionary<string, Texture2D>();
            loadContent();
        }

        private void loadContent()
        {
            /// Load Green Link textures
            Textures.Add("greenlinkrundown", game.Content.Load<Texture2D>("link/link_rundown"));
            Textures.Add("greenlinkrunup", game.Content.Load<Texture2D>("link/link_runup"));
            Textures.Add("greenlinkrunleft", game.Content.Load<Texture2D>("link/link_runleft"));
            Textures.Add("greenlinkrunright", game.Content.Load<Texture2D>("link/link_runright"));
            Textures.Add("greenlinkrundownmagicshield", game.Content.Load<Texture2D>("link/link_rundown_magicalshield"));
            Textures.Add("greenlinkrunleftmagicshield", game.Content.Load<Texture2D>("link/link_runleft_magicalshield"));
            Textures.Add("greenlinkrunrightmagicshield", game.Content.Load<Texture2D>("link/link_runright_magicalshield"));
            Textures.Add("greenlinkitempickup", game.Content.Load<Texture2D>("link/link_itempickup"));
            Textures.Add("greenlinkuseitemdown", game.Content.Load<Texture2D>("link/link_useitem_down"));
            Textures.Add("greenlinkuseitemup", game.Content.Load<Texture2D>("link/link_useitem_up"));
            Textures.Add("greenlinkuseitemleft", game.Content.Load<Texture2D>("link/link_useitem_left"));
            Textures.Add("greenlinkuseitemright", game.Content.Load<Texture2D>("link/link_useitem_right"));
            Textures.Add("greenlinkwoodenswordattackdown", game.Content.Load<Texture2D>("link/link_woodensword_attack_down"));
            Textures.Add("greenlinkwoodenswordattackup", game.Content.Load<Texture2D>("link/link_woodensword_attack_up"));
            Textures.Add("greenlinkwoodenswordattackleft", game.Content.Load<Texture2D>("link/link_woodensword_attack_left"));
            Textures.Add("greenlinkwoodenswordattackright", game.Content.Load<Texture2D>("link/link_woodensword_attack_right"));

            // Load projectiles
            Textures.Add("swordbeamright", game.Content.Load<Texture2D>("effects/effect_swordbeam_right"));
            Textures.Add("swordbeamleft", game.Content.Load<Texture2D>("effects/effect_swordbeam_left"));
            Textures.Add("swordbeamdown", game.Content.Load<Texture2D>("effects/effect_swordbeam_down"));
            Textures.Add("swordbeamup", game.Content.Load<Texture2D>("effects/effect_swordbeam_up"));
            Textures.Add("swordburstupleft", game.Content.Load<Texture2D>("effects/effect_swordburst_upleft"));
            Textures.Add("swordburstupright", game.Content.Load<Texture2D>("effects/effect_swordburst_upright"));
            Textures.Add("swordburstdownleft", game.Content.Load<Texture2D>("effects/effect_swordburst_downleft"));
            Textures.Add("swordburstdownright", game.Content.Load<Texture2D>("effects/effect_swordburst_downright"));
        }

        public Texture2D GetTexture(string name)
        {
            if(Textures.ContainsKey(name))
                return Textures[name];
            return null;
        }
    }
}
